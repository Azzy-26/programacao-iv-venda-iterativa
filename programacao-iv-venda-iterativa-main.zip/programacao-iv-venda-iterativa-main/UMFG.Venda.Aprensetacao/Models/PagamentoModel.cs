﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UMFG.Venda.Aprensetacao.Models
{
    public class PagamentoModel
    {
        [Required(ErrorMessage = "O nome é obrigatorio.")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Numero do cartão é obrigatorio.")]
        [CreditCard(ErrorMessage = "Numero do cartão invalido.")]
        public string NumeroCartao { get; set; }

        [Required(ErrorMessage = "Data de vencimento obrigatoria")]
        [RegularExpression(@"^(0[1-9]|1[0-2])\/((20)\d{2})$", ErrorMessage = "Use MM/yyyy.")]
        public string DataVencimento { get; set; }

        [Required(ErrorMessage = "CVV Obrigatorio.")]
        [RegularExpression(@"^\d{3}$", ErrorMessage = "O CCV deve conter 3 digitos")]
        public string CVV { get; set; }
    }
}
